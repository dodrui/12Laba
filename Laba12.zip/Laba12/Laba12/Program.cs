﻿using Laba10;

namespace Laba12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu<Aircraft>.StartProgram2();
        }
    }
}
