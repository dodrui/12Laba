﻿using Laba10;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba12
{
    public class Hashtable
    {
        public class HashTable<T>
        {
            T[] table; // Создание таблицы
            int cnt = 0; // Счетчик элементов в таблице
            double fillRatio; // Коэффициент заполненности таблицы
            public bool[] WasRemoved; // Массив из булевых ф-ий, для поиска в таблице после удаления эл-та

            public int Capacity => table.Length; // Кол-во памяти, которое выделено на таблицу
            public int Count => cnt; // Кол-во записей в таблице
            public HashTable(int size = 10, double fillRatio = 0.72)
            {
                table = new T[size];
                WasRemoved = new bool[size];
                this.fillRatio = fillRatio;
            }

            public void Print()
            {
                int num = 1;
                foreach (T t in table)
                {
                    Console.WriteLine($"{num}: {t}");
                    num++;
                }
            }

            public int GetIndex(T data)
            {
                return Math.Abs(data.GetHashCode()) % Capacity;
            }

            void AddData(T data)
            {
                if (data == null) return; // Добавляется пустой элемент
                int index = GetIndex(data); // Вычисляем индекс куда добавлять
                int current = index; // Запоминаем индекс
                if (table[index] != null) // Если занято, то...
                {
                    while (current < table.Length && table[current] != null) // ...идем до конца таблицы или первого пустого места
                    {
                        current++;
                    }

                    if (current == table.Length) // Если таблица закончилась, то...
                    {
                        current = 0;
                        while (current < index && table[current] != null) // ...идем с начала таблицы до индекса
                            current++;
                        // Места нет
                        if (current == index)
                        {
                            throw new Exception("Ошибка! В таблице нет места");
                        }
                    }
                }
                // Место найдено
                table[current] = data;
                cnt++;
            }

            public int GetItemIndex(T data)
            {
                int index = GetIndex(data); // Находим индекс
                if (table[index] == null && !WasRemoved[index]) return -1;
                // Есть элемент который совпадает
                if (table[index] != null && table[index].Equals(data))
                    return index;
                // Нет совпадающего элемента
                else
                {
                    // Идем вниз по таблице
                    int current = index;
                    while (current < table.Length)
                    {
                        if (table[current] != null && table[current].Equals(data)) // Совпадает
                            return current;
                        current++;
                    }
                    // Идем с начала таблицы
                    current = 0;
                    while (current < index)
                    {
                        if (table[current] != null && table[current].Equals(data)) // Совпадает
                            return current;
                        current++;
                    }
                    // Не найден
                    return -1;
                }
            }

            public void FindItem(T data)
            {
                int idx = GetItemIndex(data);
                if (idx == -1)
                    Console.WriteLine("Элемент не найден!");
                else
                    Console.WriteLine($"Элемент находится под номером {idx + 1}");

            }

            public bool Contains(T data)
            {
                return (GetItemIndex(data) >= 0);
            }

            public bool RemoveData(T data)
            {
                int index = GetItemIndex(data);
                if (index < 0) 
                {
                    Console.WriteLine("Элемент не найден!");
                    return false;
                }
                // Если элемент нашелся
                cnt--;
                table[index] = default;
                WasRemoved[index] = true;
                Console.WriteLine("Элемент удален!");
                return true;
            }

            public void AddItem(T item)
            {
                if ((double)Count / Capacity > fillRatio) // Место в таблице закончилось
                {
                    // Увеличиваем таблицу в 2 раза
                    T[] temp = (T[])table.Clone();
                    table = new T[temp.Length * 2];
                    cnt = 0;
                    for (int i = 0; i < temp.Length; i++)
                        AddData(temp[i]);

                    bool[] tempBool = new bool[WasRemoved.Length];
                    for (int i = 0; i < WasRemoved.Length; i++)
                        tempBool[i] = WasRemoved[i];

                    WasRemoved = new bool[tempBool.Length * 2];

                    for (int i = 0; i < tempBool.Length; i++)
                        WasRemoved[i] = tempBool[i];
                }
                AddData(item);
            }
        }
    }
}
