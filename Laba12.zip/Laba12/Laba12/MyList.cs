﻿using Laba10;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba12
{
    public class MyList<T> where T : IInit, ICloneable, new()
    {
        public Point<T>? beg = null;
        public Point<T>? end = null;

        int count = 0;

        public int Count => count;

        // Создание блока, со случайной data, начало и конец - null
        public Point<T> MakeRandomPoint()
        {
            T data = new T();
            data.RandomInit();
            return new Point<T>(data);
            //начало и конец = null, data из дсч
        }

        // Создание случайного элемента
        public T MakeRandomItem()
        {
            T data = new T();
            data.RandomInit();
            return data;
        }

        // Ввод элемента
        public T MakeInitItem()
        {
            T data = new T();
            data.Init();
            return data;
        }

        // Заполнение двусвязного списка
        public void AddToBegin(T item)
        {
            T newData = (T)item.Clone();
            Point<T> newItem = new Point<T>(newData);
            count++;

            if (beg != null)
            {
                beg.Previous = newItem;
                newItem.Next = beg;
                beg = newItem;
            }
            else
            {
                beg = newItem;
                end = beg;
            }
        }

        public void AddToEnd(T item)
        {
            T newData = (T)item.Clone();
            Point<T> newItem = new Point<T>(newData);

            if (end != null)
            {
                end.Next = newItem;
                newItem.Previous = end;
                end = newItem;
            }
            else
            {
                beg = end = newItem;
            }
            count++;
        }

        public void AddByPosition(T item, int pos)
        {
            pos -= 1;
            if (pos < 0 || pos > Count)
                throw new Exception("Ошибка! Позиция меньше 1 или больше количества элементов");

            T newData = (T)item.Clone();
            Point<T> newItem = new Point<T>(newData);

            if (pos == 0)
            {
                AddToBegin(newData);
                return;
            }
            else if (pos == Count)
            {
                AddToEnd(newData);
                return;
            }
            else
            {
                Point<T>? current = beg;
                for (int i = 1; i < pos - 1; i++)
                {
                    current = current.Next;
                }

                newItem.Next = current.Next;
                newItem.Previous = current;
                current.Next = newItem;
                newItem.Next.Previous = newItem;
                count++;
            }
        }

        public void RemoveOdd()
        {
            if (Count == 0)
                throw new Exception("Список пуст!");
            Point<T>? current = beg;
            int index = 0;
            while (current != null)
            {
                if (index % 2 == 0)
                {
                    if (current.Previous != null)
                        current.Previous.Next = current.Next;
                    else
                        beg = current.Next;
                    if (current.Next != null)
                        current.Next.Previous = current.Previous;
                    else
                        end = current.Previous;
                    count--;
                }

                current = current.Next;
                index++;
            }
        }

        public MyList() { }

        public MyList(int len)
        {
            if (len <= 0)
                throw new Exception("Ошибка! Длина должна быть больше 0");
            beg = MakeRandomPoint();
            end = beg;
            count++;
            for (int i = 0; i < len - 1; i++)
            {
                T newItem = MakeRandomItem();
                AddToEnd(newItem);
            }
        }

        public MyList(T[] collection)
        {
            if (collection == null)
                throw new Exception("Ошибка! Тип коллекции отсутствует");
            if (collection.Length == 0)
                throw new Exception("Ошибка! Длина равна 0");

            T newData = (T)collection.Clone();
            beg = new Point<T>(newData);
            end = beg;
            for (int i = 0; i < collection.Length; i++)
            {
                AddToEnd(collection[i]);
            }
        }

        public void PrintList()
        {
            if (Count == 0)
                Console.WriteLine("Коллекция пуста!");
            Point<T>? current = beg;
            for (int i = 0; current != null; i++)
            {
                Console.WriteLine($"{i + 1} {current}");
                current = current.Next;
            }
        }

        public MyList<T> Copy()
        {
            MyList<T> newList = new MyList<T>();

            // Если список пуст
            if (beg == null)
                return newList;

            //Переписываем элемнты в новый список
            Point<T>? current = beg;
            while (current != null)
            {
                T dataToCopy = (T)current.Data.Clone();
                newList.AddToEnd(dataToCopy);
                current = current.Next;
            }

            return newList;
        }

        public void ChangeData()
        {
            T newData = new();
            newData.RandomInit();
            if (beg != null)
            {
                beg.Data = newData;
            }
        }

        public void Clear()
        {
            // Удаляем список из памяти, установив для beg и end значения null
            beg = null;
            end = null;
            // Сбрасываем счетчик
            count = 0;
        }
    }
}
