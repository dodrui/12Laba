﻿using Laba10;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Laba12.Hashtable;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Laba12
{
    public class Menu<T> where T : IInit, ICloneable, new()
    {
        public static void PrintMenu()
        {
            Console.WriteLine("===========================\n" +
               "1) Добавить элемент в начало списка\n" +
               "2) Добавить элемент в конец списка\n" +
               "3) Добавить элемент в список по номеру\n" +
               "4) Удалить элементы с нечетным порядком из списка\n" +
               "5) Вывести список\n" +
               "6) Вывести вспомогательный список\n" +
               "7) Сделать копию списка\n" +
               "8) Отчистить список\n" +
               "0) Завершить работу\n" +
               "===========================");
        }

        public static void InsertTypeMenu()
        {
            Console.WriteLine("---------------------------\n" +
                "1) Ввести случайный элемент\n" +
                "2) Ввести элемент с клавиатуры");
        }

        public static void PrintMenu2()
        {
            Console.WriteLine("===========================\n" +
                "1) Напечатать таблицу\n" +
                "2) Добавить элемент\n" +
                "3) Поиск элемента\n" +
                "4) Удаление элемента\n" +
                "0) Завершить работу\n" +
                "===========================");
        }

        public static void ChooseTypeMenu()
        {
            Console.WriteLine("---------------------------\n" +
                "1) Воздушное судно\n" +
                "2) Вертолет\n" +
                "3) Самолет\n" +
                "4) Истребитель");
        }

        public static int InsertType()
        {
            int typeNum;
            do
            {
                InsertTypeMenu();
                typeNum = GetIntNum();
            } while (typeNum != 1 && typeNum != 2);
            return typeNum;
        }

        public static int GetIntNum()
        {
            int num;
            try
            {
                num = Convert.ToInt32(Console.ReadLine());
                return num;
            }
            catch
            {
                Console.WriteLine("Введено не целое число!");
                return -1;
            }
        }

        public static int ChooseType()
        {
            ChooseTypeMenu();
            int choose = GetIntNum();
            if (choose > 4 || choose < 1)
                return -1;
            return choose;
        }

        static void AddObject<T, P>(P newItem, HashTable<P> hash) where T : P, IInit, new() where P : IInit, ICloneable, new()
        {
            newItem = new T();
            ((T)newItem).RandomInit();
            hash.AddItem(newItem);
        }
        static void AddElem(HashTable<Aircraft> hash)
        {
            int choose = ChooseType();
            Aircraft newElem = null;
            switch (choose)
            {
                case 1:
                    AddObject<Aircraft, Aircraft>(newElem, hash);
                    break;
                case 2:
                    AddObject<Helecopter, Aircraft>(newElem, hash);
                    break;
                case 3:
                    AddObject<Plane, Aircraft>(newElem, hash);
                    break;
                case 4:
                    AddObject<Jet, Aircraft>(newElem, hash);
                    break;
                default:
                    Console.WriteLine("Ошибка! Неверно выбран тип");
                    break;
            }
        }

        public static void StartProgram()
        {
            // Создадим список для работы
            MyList<T> list = new MyList<T>();
            MyList<T> copied = new MyList<T>();

            while (true)
            {
                PrintMenu();
                int action = GetIntNum();
                T newPoint = new T(); // Элемент для обработки
                switch (action)
                {
                    case 1:
                        switch (InsertType())
                        {
                            case 1:
                                newPoint = list.MakeRandomItem();
                                list.AddToBegin(newPoint);
                                Console.WriteLine("Элемент успешно добавлен!");
                                break;
                            case 2:
                                newPoint = list.MakeInitItem();
                                list.AddToBegin(newPoint);
                                Console.WriteLine("Элемент успешно добавлен!");
                                break;
                            case 3:
                                break;
                        }
                        break;
                    case 2:
                        switch (InsertType())
                        {
                            case 1:
                                newPoint = list.MakeRandomItem();
                                list.AddToEnd(newPoint);
                                Console.WriteLine("Элемент успешно добавлен!");
                                break;
                            case 2:
                                newPoint = list.MakeInitItem();
                                list.AddToEnd(newPoint);
                                Console.WriteLine("Элемент успешно добавлен!");
                                break;
                            case 3:
                                break;
                        }
                        break;
                    case 3:
                        int choise = InsertType();
                        switch (choise)
                        {
                            case 1:
                                newPoint = list.MakeRandomItem();
                                break;
                            case 2:
                                newPoint = list.MakeInitItem();
                                break;
                            case 3:
                                break;
                        }
                        if (choise != 3)
                        {
                            try // Проверка сущ-ет ли позиция
                            {
                                Console.WriteLine("Введите позицию для добавления элемента:");
                                int pos = GetIntNum();
                                list.AddByPosition(newPoint, pos);
                                Console.WriteLine("Элемент успешно добавлен!");
                            }
                            catch (Exception ex) { Console.WriteLine(ex.Message); }
                            break;
                        }
                        break;
                    case 4:
                        try
                        {
                            list.RemoveOdd();
                            Console.WriteLine("Элементы успешно удалены!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case 5:
                        Console.WriteLine("---------\n" +
                            "Список:");
                        list.PrintList();
                        Console.WriteLine("---------");
                        break;
                    case 6:
                        Console.WriteLine("---------\n" +
                            "Список:");
                        copied.PrintList();
                        Console.WriteLine("---------");
                        break;
                    case 7:
                        copied = list.Copy();
                        Console.WriteLine("Копия списка:");
                        copied.PrintList();
                        list.ChangeData();
                        Console.WriteLine("В списке заменен первый объект");
                        break;
                    case 8:
                        list.Clear();
                        Console.WriteLine("Список отчищен");
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Не существует варианта выбора с введенным номером!");
                        break;
                }
            }
        }
        public static void StartProgram2()
        {
            HashTable<Aircraft> hash = new HashTable<Aircraft>();
            while (true)
            {
                PrintMenu2();
                int action = GetIntNum();

                switch (action)
                {
                    case 1:
                        hash.Print();
                        break;
                    case 2:
                        AddElem(hash);
                        break;
                    case 3:
                        Aircraft forSearch = new Aircraft();
                        forSearch.Init();
                        hash.FindItem(forSearch);
                        break;
                    case 4:
                        Aircraft forDelete = new Aircraft();
                        forDelete.Init();
                        hash.RemoveData(forDelete);
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Не существует варианта выбора с введенным номером!");
                        break;
                }
            }
        }
    }
}
