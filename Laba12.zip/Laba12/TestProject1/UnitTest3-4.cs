﻿using Laba10;
using Lab12_3;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Laba12_3;

namespace Lab12_3_Tests
{
    [TestClass]
    public class AVLTreeTests
    {
        [TestMethod]
        public void TestConstructor_Default()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Assert.AreEqual(0, tree.Count);
            Assert.IsNull(tree.root);
        }

        [TestMethod]
        public void TestConstructor_WithLength()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(4);
            Assert.AreEqual(4, tree.Count);
            Assert.IsNotNull(tree.root);
        }

        [TestMethod]
        public void TestAdd()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data = new Aircraft();
            data.RandomInit();
            tree.Add(data);
            Assert.IsTrue(tree.Contains(data));
        }

        [TestMethod]
        public void TestInsert()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data = new Aircraft();
            tree.Insert(data); 
            Assert.IsTrue(tree.Contains(data));
        }

        [TestMethod]
        public void TestDelete()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data1 = new Aircraft();
            tree.Add(data1);
            tree.Delete(data1);
            Assert.AreEqual(0, tree.Count);
            Assert.IsFalse(tree.Contains(data1));
        }

        [TestMethod]
        public void TestDelete_NonExistentElement()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data1 = new Aircraft();
            Aircraft data2 = new Aircraft(1977);
            tree.Add(data1);
            tree.Delete(data2);
            Assert.IsTrue(tree.Contains(data1));
            Assert.IsFalse(tree.Contains(data2));
        }

        [TestMethod]
        public void TestClear()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(5);
            tree.Clear();
            Assert.AreEqual(0, tree.Count);
            Assert.IsNull(tree.root);
        }

        [TestMethod]
        public void TestContains()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data = new Aircraft();
            tree.Add(data);
            Assert.IsTrue(tree.Contains(data));
            tree.Delete(data);
            Assert.IsFalse(tree.Contains(data));
        }

        [TestMethod]
        public void TestGetTreeHeight()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>();
            Aircraft data1 = new Aircraft();
            Aircraft data2 = new Aircraft();
            tree.Add(data1);
            tree.Add(data2);
            int height = tree.GetTreeHeight();
            Assert.IsTrue(height >= 1);
        }

        [TestMethod]
        public void TestCopyConstructor()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(3);
            AVLTree<Aircraft> copyTree = new AVLTree<Aircraft>(tree);
            Point<Aircraft>? current = tree.root;
            Point<Aircraft>? currentCopy = copyTree.root;
            while (current != null && currentCopy != null)
            {
                Assert.AreEqual(current.Data, currentCopy.Data);
                current = current.Left;
                currentCopy = currentCopy.Left;
            }
        }

        [TestMethod]
        public void TestDeleteTree()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(3);
            tree.DeleteTree();
            Assert.AreEqual(0, tree.Count);
            Assert.IsNull(tree.root);
        }

        [TestMethod]
        public void TestCopyTo()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(3);
            Aircraft[] array = new Aircraft[5];
            tree.CopyTo(array, 0);
            for (int i = 0; i < tree.Count; i++)
            {
                Assert.IsNotNull(array[i]);
            }
        }

        [TestMethod]
        public void TestEnumerator()
        {
            AVLTree<Aircraft> tree = new AVLTree<Aircraft>(3);
            int count = 0;
            foreach (Aircraft item in tree)
            {
                count++;
            }
            Assert.AreEqual(tree.Count, count);
        }
    }
}
