﻿using Laba10;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba12;
using static Laba12.Hashtable;

namespace TestProject1
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestAddItem_SingleElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            table.AddItem(a);
            Assert.AreEqual(1, table.Count);
            Assert.IsTrue(table.Contains(a));
        }

        [TestMethod]
        public void TestAddItem_MultipleElements()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            for (int i = 0; i < 20; i++)
            {
                Aircraft a = new Aircraft { Id = i };
                table.AddItem(a);
                Assert.IsTrue(table.Contains(a));
            }
            Assert.AreEqual(20, table.Count);
        }

        [TestMethod]
        public void TestAddItem_TriggerResize()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>(5);
            for (int i = 0; i < 10; i++)
            {
                Aircraft a = new Aircraft { Id = i };
                table.AddItem(a);
            }
            Assert.AreEqual(10, table.Count);
            Assert.IsTrue(table.Capacity > 5);
        }

        [TestMethod]
        public void TestRemoveData_ExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            table.AddItem(a);
            Assert.IsTrue(table.Contains(a));
            Assert.IsTrue(table.RemoveData(a));
            Assert.IsFalse(table.Contains(a));
            Assert.AreEqual(0, table.Count);
        }

        [TestMethod]
        public void TestRemoveData_NonExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            Assert.IsFalse(table.RemoveData(a));
        }

        [TestMethod]
        public void TestContains_ExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            table.AddItem(a);
            Assert.IsTrue(table.Contains(a));
        }

        [TestMethod]
        public void TestContains_NonExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            Assert.IsFalse(table.Contains(a));
        }

        [TestMethod]
        public void TestGetItemIndex_ExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            table.AddItem(a);
            int index = table.GetItemIndex(a);
            Assert.AreNotEqual(-1, index);
        }

        [TestMethod]
        public void TestGetItemIndex_NonExistingElement()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            int index = table.GetItemIndex(a);
            Assert.AreEqual(-1, index);
        }

        [TestMethod]
        public void TestGetIndex()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            int index = table.GetIndex(a);
            Assert.IsTrue(index >= 0 && index < table.Capacity);
        }

        [TestMethod]
        public void TestWasRemovedFlag()
        {
            HashTable<Aircraft> table = new HashTable<Aircraft>();
            Aircraft a = new Aircraft();
            table.AddItem(a);
            table.RemoveData(a);
            Assert.IsTrue(table.WasRemoved[table.GetIndex(a)]);
        }
    }
}
