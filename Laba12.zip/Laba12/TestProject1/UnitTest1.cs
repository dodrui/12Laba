using Laba10;
using Laba12;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Laba12
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MyList<Aircraft> expected = new MyList<Aircraft>();
        }

        [TestMethod]
        public void TestMethod2()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w = new Aircraft();
            list.AddToBegin(w);
            list.AddToBegin(w);
            Assert.AreEqual(2, list.Count);
        }

        [TestMethod]
        public void TestMethod3()
        {
            MyList<Aircraft> list = new MyList<Aircraft>(4);
            Assert.AreEqual(4, list.Count);
        }

        [TestMethod]
        public void TestMethod5()
        {
            MyList<Aircraft> myList = new MyList<Aircraft>();
            Aircraft w = new Aircraft();
            myList.AddToBegin(w);
            myList.AddToEnd(w);
            myList.RemoveOdd();
            Assert.AreEqual(1, myList.Count);
        }

        [TestMethod]
        public void TestMethod6()
        {
            MyList<Aircraft> myList = new MyList<Aircraft>(3);
            MyList<Aircraft> copyList = myList.Copy();
            Assert.AreEqual(myList.Count, copyList.Count);
        }

        [TestMethod]
        public void TestMethod7()
        {
            MyList<Aircraft> myList = new MyList<Aircraft>(3);
            myList.Clear();
            Assert.AreEqual(0, myList.Count);
        }

        [TestMethod]
        public void TestMethod8()
        {
            MyList<Aircraft> myList = new MyList<Aircraft>(3);
            myList.PrintList();
        }

        [TestMethod]
        public void TestAddToBegin_MultipleElements()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w1 = new Aircraft();
            Aircraft w2 = new Aircraft();
            list.AddToBegin(w1);
            list.AddToBegin(w2);
            Assert.AreEqual(2, list.Count);
            Assert.AreEqual(w2, list.beg.Data);
            Assert.AreEqual(w1, list.beg.Next.Data);
        }

        [TestMethod]
        public void TestAddToEnd_SingleElement()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w = new Aircraft();
            list.AddToEnd(w);
            Assert.AreEqual(1, list.Count);
            Assert.AreEqual(w, list.beg.Data);
            Assert.AreEqual(w, list.end.Data);
        }

        [TestMethod]
        public void TestAddToEnd_MultipleElements()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w1 = new Aircraft();
            Aircraft w2 = new Aircraft();
            list.AddToEnd(w1);
            list.AddToEnd(w2);
            Assert.AreEqual(2, list.Count);
            Assert.AreEqual(w1, list.beg.Data);
            Assert.AreEqual(w2, list.end.Data);
        }

        public void TestAddByPosition_AddToBeginning()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w = new Aircraft();
            list.AddByPosition(w, 1);

            Assert.AreEqual(w, list.beg.Data);
        }

        [TestMethod]
        public void TestAddByPosition_AddToEnd()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w1 = new Aircraft();
            Aircraft w2 = new Aircraft();
            list.AddToEnd(w1);
            list.AddByPosition(w2, 1);

            Assert.AreEqual(2, list.Count);
            Assert.AreEqual(w2, list.beg.Data);
            Assert.AreEqual(w1, list.end.Data);
        }

        [TestMethod]
        public void TestAddByPosition_AddToMiddle()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w1 = new Aircraft();
            Aircraft w2 = new Aircraft();
            Aircraft w3 = new Aircraft();
            list.AddToEnd(w1);
            list.AddToEnd(w3);
            list.AddByPosition(w2, 2);

            Assert.AreEqual(3, list.Count);
            Assert.AreEqual(w1, list.beg.Data);
            Assert.AreEqual(w2, list.beg.Next.Data);
            Assert.AreEqual(w3, list.end.Data);
        }

        [TestMethod]
        public void TestAddByPosition_InvalidPosition_ThrowsException()
        {
            MyList<Aircraft> list = new MyList<Aircraft>();
            Aircraft w = new Aircraft();

            Assert.ThrowsException<Exception>(() => list.AddByPosition(w, 0));
            Assert.ThrowsException<Exception>(() => list.AddByPosition(w, 2));
        }
    }
}