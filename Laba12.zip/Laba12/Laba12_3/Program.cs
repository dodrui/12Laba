﻿using Laba10;
using Lab12_3;
namespace Laba12_3
{
    internal class Program
    {
        public static int InputNum()
        {
            bool isConvert;
            int number;
            do
            {
                isConvert = int.TryParse(Console.ReadLine(), out number);
                if (!isConvert)
                    Console.WriteLine("Неправильный ввод!");
            } while (!isConvert);
            return number;
        }
        public static void PrintMenu3()
        {
            Console.WriteLine("===========================" +
                "\n1) Добавить элемент в дерево" +
                "\n2) Вывести дерево" +
                "\n3) Вывести минимальный элемент дерева" +
                "\n4) Удалить дерево" +
                "\n5) Удалить элемент из дерева" +
                "\n0) Завершить работу" +
                "\n===========================");
        }

        public static void PrintMenu4()
        {
            Console.WriteLine("===========================" +
                "\n1) Создать дерево произвольной длины" +
                "\n2) Добавить элемент в дерево" +
                "\n3) Удалить элемент из дерева" +
                "\n4) Удалить дерево" +
                "\n5) Вывести дерево" +
                "\n6) Вывести дерево через foreach" +
                "\n7) Проперить наличие элемента в дереве" +
                "\n0) Завершить работу" +
                "\n===========================");
        }
        static void StartPart3()
        {
            AVLTree<Aircraft> avlTree = new AVLTree<Aircraft>();
            int choose = -1;
            while (choose != 0)
            {
                PrintMenu3();
                choose = InputNum();
                switch (choose)
                {
                    case 1:
                        Aircraft n = new Aircraft();
                        n.RandomInit();
                        avlTree.Insert(n);
                        Console.WriteLine("Элемент добавлен!");
                        break;
                    case 2:
                        Console.WriteLine("Дерево:");
                        avlTree.ShowTree();
                        break;
                    case 3:
                        Console.WriteLine("Минимальный элемент дерева:");
                        Console.WriteLine(avlTree.ShowMinElem(avlTree));
                        break;
                    case 4:
                        avlTree.DeleteTree();
                        Console.WriteLine("Дерево удалено!");
                        break;
                    case 5:
                        Aircraft forDel = new Aircraft();
                        forDel.Init();
                        avlTree.Delete(forDel);
                        Console.WriteLine("Попытка удаления произведена!");
                        break;
                }
            }
        }

        static void StartPart4()
        {
            AVLTree<Aircraft> avlTree = new AVLTree<Aircraft>();
            int choose = -1;
            while (choose != 0)
            {
                PrintMenu4();
                choose = InputNum();
                switch (choose)
                {
                    case 1:
                        Console.Write("Введите длину коллекции: ");
                        int length;
                        if (int.TryParse(Console.ReadLine(), out length) && length > 0)
                        {
                            avlTree = new AVLTree<Aircraft>(length);
                            Console.WriteLine($"Коллекция из {length} элементов создана.");
                        }
                        else
                            Console.WriteLine("Неверно введена длина. Попробуйте снова.");
                        break;
                    case 2:
                        Aircraft toAdd = new Aircraft();
                        toAdd.RandomInit();
                        avlTree.Add(toAdd);
                        Console.WriteLine("Элемент добавлен.");
                        break;
                    case 3:
                        Aircraft forDel = new Aircraft();
                        forDel.Init();
                        avlTree.Delete(forDel);
                        Console.WriteLine("Попытка удаления произведена!");
                        break;
                    case 4:
                        avlTree.DeleteTree();
                        Console.WriteLine("Дерево удалено!");
                        break;
                    case 5:
                        Console.WriteLine("Дерево:");
                        avlTree.ShowTree();
                        break;
                    case 6:
                        Console.WriteLine("Элементы дерева:");
                        foreach (var item in avlTree)
                            Console.WriteLine(item);
                        break;
                    case 7:
                        Aircraft toFind = new Aircraft();
                        toFind.Init();
                        if (avlTree.Contains(toFind))
                            Console.WriteLine("Элемент найден.");
                        else
                            Console.WriteLine("Элемент не найден.");
                        break;
                }
            }
        }
        static void Main(string[] args)
        {
            StartPart4();
        }
    }
}
